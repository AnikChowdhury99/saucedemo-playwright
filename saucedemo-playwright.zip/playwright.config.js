import { defineConfig } from '@playwright/test';

export default defineConfig({
  timeout: 60000,
  use: {
    headless: true,
    baseURL: "https://www.saucedemo.com/"
  }
});
