// @ts-check
import { test, expect } from '@playwright/test';

test('User logs in, adds product to cart, verifies it, and logs out', async ({ page }) => {
  await page.goto('/');

  // Login
  await page.fill('#user-name', 'standard_user');
  await page.fill('#password', 'secret_sauce');
  await page.click('#login-button');

  // Verify login successful
  await expect(page.locator('.title')).toHaveText('Products');

  // Add a product to the cart
  const firstProduct = page.locator('.inventory_item').first();
  const productName = await firstProduct.locator('.inventory_item_name').innerText();
  await firstProduct.locator('button').click();

  // Go to the cart
  await page.click('.shopping_cart_link');

  // Verify the product name in cart
  const cartItemName = await page.locator('.inventory_item_name').innerText();
  expect(cartItemName).toBe(productName);

  // Open menu
  await page.click('#react-burger-menu-btn');

  // Click logout
  await page.click('#logout_sidebar_link');

  // Verify logout success
  await expect(page.locator('#login-button')).toBeVisible();
});
